const TAX_RATES = {
  US: 0.21,
  EU: 0.20,
  UK: 0.19,
  JP: 0.23
};

export const calculateTax = async (transaction) => {
  // This is a simplified tax calculation
  // In a real application, this would be much more complex
  // and would consider various factors like:
  // - User's jurisdiction
  // - Transaction type
  // - Holding period
  // - Capital gains vs. regular income
  // - Tax treaties between countries
  // - etc.

  const jurisdiction = 'US'; // This would normally be determined by user's location
  const taxRate = TAX_RATES[jurisdiction];
  
  // Only calculate tax for certain transaction types
  if (transaction.type === 'withdrawal' || transaction.type === 'transfer') {
    const taxableAmount = transaction.amount;
    const taxAmount = taxableAmount * taxRate;

    return {
      jurisdiction,
      tax_rate: taxRate,
      tax_amount: taxAmount,
      category: transaction.currency === 'USDC' ? 'stablecoin' : 'crypto',
      year: new Date().getFullYear()
    };
  }

  return null;
};