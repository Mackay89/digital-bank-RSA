import express from 'express';
import { supabase } from '../index.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

router.get('/summary', authenticateToken, async (req, res) => {
  try {
    const year = req.query.year || new Date().getFullYear();

    const { data: taxRecords, error } = await supabase
      .from('tax_records')
      .select(`
        jurisdiction,
        tax_rate,
        tax_amount,
        category,
        transactions(amount, currency, type)
      `)
      .eq('user_id', req.user.id)
      .eq('year', year);

    if (error) throw error;

    const summary = {
      totalTaxable: 0,
      estimatedTax: 0,
      transactions: taxRecords.length,
      globalRates: {},
      stablecoinGains: 0
    };

    taxRecords.forEach(record => {
      summary.totalTaxable += record.transactions.amount;
      summary.estimatedTax += record.tax_amount;
      summary.globalRates[record.jurisdiction] = record.tax_rate;
      
      if (record.category === 'stablecoin') {
        summary.stablecoinGains += record.tax_amount;
      }
    });

    res.json(summary);
  } catch (error) {
    logger.error('Get tax summary error:', error);
    res.status(400).json({ error: 'Failed to fetch tax summary' });
  }
});

router.get('/report', authenticateToken, async (req, res) => {
  try {
    const year = req.query.year || new Date().getFullYear();

    const { data: report, error } = await supabase
      .from('tax_records')
      .select(`
        *,
        transactions(*)
      `)
      .eq('user_id', req.user.id)
      .eq('year', year)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json(report);
  } catch (error) {
    logger.error('Get tax report error:', error);
    res.status(400).json({ error: 'Failed to fetch tax report' });
  }
});

export const taxRouter = router;