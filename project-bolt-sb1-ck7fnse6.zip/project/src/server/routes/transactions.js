import express from 'express';
import { z } from 'zod';
import { supabase } from '../index.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { logger } from '../utils/logger.js';
import { calculateTax } from '../utils/taxCalculator.js';
import { ethers } from 'ethers';

const router = express.Router();

const transactionSchema = z.object({
  type: z.enum(['deposit', 'withdrawal', 'transfer']),
  amount: z.number().positive(),
  currency: z.string(),
  blockchain: z.string().optional(),
  toAddress: z.string().optional(),
  settlementType: z.string()
});

router.get('/', authenticateToken, async (req, res) => {
  try {
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json(transactions);
  } catch (error) {
    logger.error('Get transactions error:', error);
    res.status(400).json({ error: 'Failed to fetch transactions' });
  }
});

router.post('/', authenticateToken, validateRequest(transactionSchema), async (req, res) => {
  try {
    const { type, amount, currency, blockchain, toAddress, settlementType } = req.body;

    // Start a transaction
    const { data: { user }, error: userError } = await supabase
      .from('users')
      .select('wallet_address, preferred_network')
      .eq('id', req.user.id)
      .single();

    if (userError) throw userError;

    // Generate blockchain transaction if needed
    let hash = null;
    if (blockchain) {
      // In production, this would interact with actual blockchain
      hash = ethers.hexlify(ethers.randomBytes(32));
    }

    // Create transaction record
    const { data: transaction, error: txError } = await supabase
      .from('transactions')
      .insert({
        user_id: req.user.id,
        type,
        amount,
        currency,
        blockchain: blockchain || user.preferred_network,
        hash,
        settlement_type: settlementType,
        from_address: user.wallet_address,
        to_address: toAddress,
        status: 'completed'
      })
      .select()
      .single();

    if (txError) throw txError;

    // Update balance
    const multiplier = type === 'deposit' ? 1 : -1;
    const { error: balanceError } = await supabase.rpc('update_balance', {
      p_user_id: req.user.id,
      p_currency: currency,
      p_amount: amount * multiplier
    });

    if (balanceError) throw balanceError;

    // Calculate and record tax
    const taxInfo = await calculateTax(transaction);
    if (taxInfo) {
      await supabase.from('tax_records').insert({
        user_id: req.user.id,
        transaction_id: transaction.id,
        ...taxInfo
      });
    }

    res.status(201).json(transaction);
  } catch (error) {
    logger.error('Create transaction error:', error);
    res.status(400).json({ error: 'Failed to create transaction' });
  }
});

export const transactionsRouter = router;