import express from 'express';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import { supabase } from '../index.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(2)
});

router.post('/login', validateRequest(loginSchema), async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const { data: { user }, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;

    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ token, user });
  } catch (error) {
    logger.error('Login error:', error);
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

router.post('/register', validateRequest(registerSchema), async (req, res) => {
  try {
    const { email, password, fullName } = req.body;

    const { data: { user }, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName
        }
      }
    });

    if (error) throw error;

    // Create initial balances for the user
    await supabase.from('balances').insert([
      { user_id: user.id, currency: 'USD', type: 'fiat', amount: 0 },
      { user_id: user.id, currency: 'ETH', type: 'crypto', amount: 0 },
      { user_id: user.id, currency: 'USDC', type: 'crypto', amount: 0 }
    ]);

    res.status(201).json({ message: 'Registration successful' });
  } catch (error) {
    logger.error('Registration error:', error);
    res.status(400).json({ error: 'Registration failed' });
  }
});

router.post('/mfa/enable', authenticateToken, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .update({ mfa_enabled: true })
      .eq('id', req.user.id);

    if (error) throw error;

    res.json({ message: 'MFA enabled successfully' });
  } catch (error) {
    logger.error('MFA enable error:', error);
    res.status(400).json({ error: 'Failed to enable MFA' });
  }
});

export const authRouter = router;