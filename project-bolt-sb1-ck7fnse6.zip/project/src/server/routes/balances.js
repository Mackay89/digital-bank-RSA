import express from 'express';
import { supabase } from '../index.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

router.get('/', authenticateToken, async (req, res) => {
  try {
    const { data: balances, error } = await supabase
      .from('balances')
      .select('*')
      .eq('user_id', req.user.id);

    if (error) throw error;

    res.json(balances);
  } catch (error) {
    logger.error('Get balances error:', error);
    res.status(400).json({ error: 'Failed to fetch balances' });
  }
});

router.get('/:currency', authenticateToken, async (req, res) => {
  try {
    const { data: balance, error } = await supabase
      .from('balances')
      .select('*')
      .eq('user_id', req.user.id)
      .eq('currency', req.params.currency)
      .single();

    if (error) throw error;

    res.json(balance);
  } catch (error) {
    logger.error('Get balance error:', error);
    res.status(400).json({ error: 'Failed to fetch balance' });
  }
});

export const balancesRouter = router;