import express from 'express';
import { z } from 'zod';
import { supabase } from '../index.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

const exchangeSchema = z.object({
  fromCurrency: z.string(),
  toCurrency: z.string(),
  amount: z.number().positive()
});

router.get('/rates', authenticateToken, async (req, res) => {
  try {
    const { data: rates, error } = await supabase
      .from('exchange_rates')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) throw error;

    res.json(rates[0]);
  } catch (error) {
    logger.error('Get exchange rates error:', error);
    res.status(400).json({ error: 'Failed to fetch exchange rates' });
  }
});

router.post('/convert', authenticateToken, validateRequest(exchangeSchema), async (req, res) => {
  try {
    const { fromCurrency, toCurrency, amount } = req.body;

    // Get latest exchange rate
    const { data: rate, error: rateError } = await supabase
      .from('exchange_rates')
      .select('rate')
      .eq('from_currency', fromCurrency)
      .eq('to_currency', toCurrency)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (rateError) throw rateError;

    const convertedAmount = amount * rate.rate;

    // Create transaction records for the exchange
    const { error: txError } = await supabase.from('transactions').insert([
      {
        user_id: req.user.id,
        type: 'withdrawal',
        amount,
        currency: fromCurrency,
        status: 'completed'
      },
      {
        user_id: req.user.id,
        type: 'deposit',
        amount: convertedAmount,
        currency: toCurrency,
        status: 'completed'
      }
    ]);

    if (txError) throw txError;

    // Update balances
    await supabase.rpc('update_balance', {
      p_user_id: req.user.id,
      p_currency: fromCurrency,
      p_amount: -amount
    });

    await supabase.rpc('update_balance', {
      p_user_id: req.user.id,
      p_currency: toCurrency,
      p_amount: convertedAmount
    });

    res.json({
      fromAmount: amount,
      toAmount: convertedAmount,
      rate: rate.rate
    });
  } catch (error) {
    logger.error('Currency conversion error:', error);
    res.status(400).json({ error: 'Failed to convert currency' });
  }
});

export const exchangeRouter = router;